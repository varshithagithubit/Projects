from django.urls import path

from . import views

urlpatterns = [path("index.html", views.index, name="index"),
	       path('UserLogin', views.UserLogin, name="UserLogin"),
	       path('UserLoginAction', views.UserLoginAction, name="UserLoginAction"),	   
	       path('Signup', views.Signup, name="Signup"),
	       path('SignupAction', views.SignupAction, name="SignupAction"),
	       path('OTPAction', views.OTPAction, name="OTPAction"),
	       path('ViewBalance', views.ViewBalance, name="ViewBalance"),	        
	       path('AddFund', views.AddFund, name="AddFund"),
	       path('AddFundAction', views.AddFundAction, name="AddFundAction"),
		   path('TransferFund', views.TransferFund, name="TransferFund"),
	       path('TransferFundAction', views.TransferFundAction, name="TransferFundAction"),
]
