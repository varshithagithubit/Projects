from django.shortcuts import render
from django.template import RequestContext
from django.contrib import messages
import pymysql
from django.http import HttpResponse
from django.core.files.storage import FileSystemStorage
import os
from Hide import *
from PIL import Image
import cv2
import numpy as np
from skimage.metrics import structural_similarity as ssim
import random
import smtplib
from datetime import date
import matplotlib.pyplot as plt

global uname, otp, email

def TransferFund(request):
    if request.method == 'GET':
        global uname
        output = '<tr><td><font size="" color="black">Receiver&nbsp;Name</b></td><td><select name="t1">'
        con = pymysql.connect(host='127.0.0.1',port = 3306,user = 'root', password = 'root', database = 'Phishing',charset='utf8')
        with con:
            cur = con.cursor()
            cur.execute("select username from signup")
            rows = cur.fetchall()
            for row in rows:
                if row[0] != uname:
                    output += '<option value="'+row[0]+'">'+row[0]+'</option>'
        output += "</select></td></tr>"
        context= {'data1':output}
        return render(request, 'TransferFund.html', context)

def TransferFundAction(request):
    if request.method == 'POST':
        global uname
        today = date.today()
        receiver = request.POST.get('t1', False)
        amount = request.POST.get('t2', False)
        status = 'none'
        con = pymysql.connect(host='127.0.0.1',port = 3306,user = 'root', password = 'root', database = 'Phishing',charset='utf8')
        deposit = 0
        withdraw = 0
        with con:
            cur = con.cursor()
            cur.execute("select * from balance where username = '"+uname+"'")
            rows = cur.fetchall()
            for row in rows:
                if row[2] == 'Deposit':
                    deposit = deposit + row[1]
                else:
                    withdraw = withdraw + row[1]
        total = deposit - withdraw
        if total > float(amount):
            db_connection = pymysql.connect(host='127.0.0.1',port = 3306,user = 'root', password = 'root', database = 'Phishing',charset='utf8')
            db_cursor = db_connection.cursor()
            student_sql_query = "INSERT INTO balance(username,Transaction_amount,Transaction_type,transaction_date) VALUES('"+uname+"','"+amount+"','Transfer','"+str(today)+"')"
            db_cursor.execute(student_sql_query)
            db_connection.commit()
            db_connection = pymysql.connect(host='127.0.0.1',port = 3306,user = 'root', password = 'root', database = 'Phishing',charset='utf8')
            db_cursor = db_connection.cursor()
            student_sql_query = "INSERT INTO balance(username,Transaction_amount,Transaction_type,transaction_date) VALUES('"+receiver+"','"+amount+"','Deposit','"+str(today)+"')"
            db_cursor.execute(student_sql_query)
            db_connection.commit()
            context= {'data':"Amount Transferred to "+receiver}
            return render(request, 'UserScreen.html', context)
        else:
            context= {'data':'Insufficient Funds'}
            return render(request, 'UserScreen.html', context)

def AddFund(request):
    if request.method == 'GET':
        return render(request, 'AddFund.html', {})

def AddFundAction(request):
    if request.method == 'POST':
        global uname
        amount = request.POST.get('t1', False)
        today = date.today()          
        status = 'Error in depositing funds'
        db_connection = pymysql.connect(host='127.0.0.1',port = 3306,user = 'root', password = 'root', database = 'Phishing',charset='utf8')
        db_cursor = db_connection.cursor()
        student_sql_query = "INSERT INTO balance(username,Transaction_amount,Transaction_type,transaction_date) VALUES('"+uname+"','"+amount+"','Deposit','"+str(today)+"')"
        db_cursor.execute(student_sql_query)
        db_connection.commit()
        print(db_cursor.rowcount, "Record Inserted")
        if db_cursor.rowcount == 1:
            status = 'Deposited '+amount+' Successfully'
        context= {'data':status}
        return render(request, 'AddFund.html', context)    

def UserLogin(request):
    if request.method == 'GET':
       return render(request, 'UserLogin.html', {})

def index(request):
    if request.method == 'GET':
       return render(request, 'index.html', {})

def Signup(request):
    if request.method == 'GET':
       return render(request, 'Signup.html', {})

def SignupAction(request):
    if request.method == 'POST':
        username = request.POST.get('t1', False)
        password = request.POST.get('t2', False)
        contact = request.POST.get('t3', False)
        email = request.POST.get('t4', False)
        address = request.POST.get('t5', False)
        cover = request.FILES['t6'].read()
        hidden = request.FILES['t7'].read()        
        status = 'none'
        con = pymysql.connect(host='127.0.0.1',port = 3306,user = 'root', password = 'root', database = 'Phishing',charset='utf8')
        with con:
            cur = con.cursor()
            cur.execute("select username from signup where username = '"+username+"'")
            rows = cur.fetchall()
            for row in rows:
                if row[0] == email:
                    status = 'Given Username already exists'
                    break
        if status == 'none':
            os.mkdir("PhishingApp/static/login/"+username)
            with open("PhishingApp/static/login/"+username+"/cover.png", "wb") as file:
                file.write(cover)
            file.close()
            with open("PhishingApp/static/login/"+username+"/hidden.png", "wb") as file:
                file.write(hidden)
            file.close()
            img_visible = Image.open("PhishingApp/static/login/"+username+"/cover.png")
            img_hidden = Image.open("PhishingApp/static/login/"+username+"/hidden.png")
            encoded_image = encode(img_visible, img_hidden)
            cv2.imwrite("PhishingApp/static/login/"+username+"/merge.png", cv2.cvtColor(np.array(encoded_image), cv2.COLOR_RGB2BGR))
            db_connection = pymysql.connect(host='127.0.0.1',port = 3306,user = 'root', password = 'root', database = 'Phishing',charset='utf8')
            db_cursor = db_connection.cursor()
            student_sql_query = "INSERT INTO signup(username,password,emailID,phone_no,residence_address) VALUES('"+username+"','"+password+"','"+email+"','"+contact+"','"+address+"')"
            db_cursor.execute(student_sql_query)
            db_connection.commit()
            print(db_cursor.rowcount, "Record Inserted")
            if db_cursor.rowcount == 1:
                img_visible = Image.open("PhishingApp/static/login/"+username+"/cover.png")
                status = 'Signup Process Completed'
                figure, axis = plt.subplots(nrows=1, ncols=3,figsize=(10,10))
                axis[0].set_title("Cover Image")
                axis[1].set_title("Hidden Image")
                axis[2].set_title("Steganography or Merge Image")
                axis[0].imshow(img_visible)
                axis[1].imshow(img_hidden)
                axis[2].imshow(encoded_image)
                figure.tight_layout()
                plt.show()
        context= {'data':status}
        return render(request, 'Signup.html', context)

def mse(imageA, imageB):
    err = np.sum((imageA.astype("float") - imageB.astype("float")) ** 2)
    err /= float(imageA.shape[0] * imageA.shape[1])
    return err

def sendOTP(email, otp_value):
    em = []
    em.append(email)
    with smtplib.SMTP_SSL('smtp.gmail.com', 465) as connection:
        email_address = 'kaleem202120@gmail.com'
        email_password = 'xyljzncebdxcubjq'
        connection.login(email_address, email_password)
        connection.sendmail(from_addr="kaleem202120@gmail.com", to_addrs=em, msg="Subject : Your OTP : "+otp_value)

def OTPAction(request):
    if request.method == 'POST':
        global otp, uname
        otp_value = request.POST.get('t1', False)
        if otp == otp_value:
            context= {'data':'Welcome '+uname}
            return render(request, 'UserScreen.html', context)
        else:
            context= {'data':'Invalid OTP! Please Retry'}
            return render(request, 'OTP.html', context)

def UserLoginAction(request):
    if request.method == 'POST':
        global uname, otp, email
        option = 0
        username = request.POST.get('username', False)
        password = request.POST.get('password', False)
        cover = request.FILES['t3'].read()
        hidden = request.FILES['t4'].read()   
        con = pymysql.connect(host='127.0.0.1',port = 3306,user = 'root', password = 'root', database = 'Phishing',charset='utf8')
        with con:
            cur = con.cursor()
            cur.execute("select * FROM signup")
            rows = cur.fetchall()
            for row in rows:
                if row[0] == username and row[1] == password:
                    uname = username
                    email = row[2]
                    option = 1
                    break
        if option == 1:
            if os.path.exists("PhishingApp/static/temp/temp.png"):
                os.remove("PhishingApp/static/temp/temp.png")
            with open("PhishingApp/static/temp/temp.png", "wb") as file:
                file.write(hidden)
            file.close()
            decoded_image = decode(Image.open("PhishingApp/static/login/"+uname+"/merge.png"))
            img1 = cv2.cvtColor(np.array(decoded_image), cv2.COLOR_RGB2BGR)
            img2 = cv2.imread("PhishingApp/static/temp/temp.png")
            img1 = cv2.resize(img1, (100, 100))
            img2 = cv2.resize(img2, (100, 100))
            img1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
            img2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)
            m = mse(img1, img2)
            s = ssim(img1, img2)
            if m == 0 and s == 1:
                otp = str(random.randint(1000, 9999))
                sendOTP(email, otp)
                context= {'data':'OTP sent to your mail'}
                return render(request, 'OTP.html', context)
            else:
                context= {'data':'Invalid Hidden image uploaded'}
                return render(request, 'UserLogin.html', context)                
        else:
            context= {'data':'Invalid login details'}
            return render(request, 'UserLogin.html', context)


def ViewBalance(request):
    if request.method == 'GET':
        global uname
        output = '<table border=1><tr><th><font size="" color=black>Username</font></th>'
        output+='<td><font size="" color="black">Transaction Amount</td>'
        output+='<td><font size="" color="black">Transaction Type</td>'
        output+='<td><font size="" color="black">Transaction Date</td></tr>'
        deposit = 0
        withdraw = 0
        con = pymysql.connect(host='127.0.0.1',port = 3306,user = 'root', password = 'root', database = 'Phishing',charset='utf8')
        with con:
            cur = con.cursor()
            cur.execute("select * FROM balance where username='"+uname+"'")
            rows = cur.fetchall()
            for row in rows:
                if row[2] == 'Deposit':
                    deposit = deposit + row[1]
                else:
                    withdraw = withdraw + row[1]
                output+='<tr><td><font size="" color="black">'+str(row[0])+'</td>'
                output+='<td><font size="" color="black">'+str(row[1])+'</td>'
                output+='<td><font size="" color="black">'+str(row[2])+'</td>'
                output+='<td><font size="" color="black">'+str(row[3])+'</td></tr>'
        output += '<tr><td><font size="" color="black">Available Balance : '+str((deposit - withdraw))+'</td>'
        output += "</table><br/><br/><br/>"
        context= {'data': output}
        return render(request, 'UserScreen.html', context)
    

