from django.apps import AppConfig


class PhishingappConfig(AppConfig):
    name = 'PhishingApp'
